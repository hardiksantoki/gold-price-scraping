import scrapy


class SpiderNameSpider(scrapy.Spider):
    name = "spider_name"
    allowed_domains = ["goldclubdirect.com"]
    start_urls = ["https://goldclubdirect.com"]

    def parse(self, response):
        pass
